﻿public class District
{
    public string Name { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public int Residents { get; set; }
    public double PvOutput { get; set; }
    public double Area { get; set; }
    public bool IsOverHalf { get; set; }

    /// <summary>
    ///  MAX refers to highest district peak based on data
    ///  provided by statistik.at/atlas on PVs in Austria
    /// </summary>
    private static double MAX = 681.77;

    public District(string _name, double _lat, double _lon, int _res, double _pvPeakPer1000, double _area)
    {
        Name = _name;
        Latitude = _lat;
        Longitude = _lon;
        Residents = _res;
        PvOutput = CalculateDistrictOutput(_pvPeakPer1000, _res);
        Area = _area;
    }

    /// <summary>
    /// Calculates theoretical district peak based on peak per 1000 residents
    /// and actual number of residents of the district 
    /// </summary>
    /// <param name="_pvPeakPer1000"></param>
    /// <param name="_res"></param>
    /// <returns></returns>
    private double CalculateDistrictOutput(double _pvPeakPer1000, int _res)
    {
        double districtOutput = (_pvPeakPer1000 / 1000) * _res;
        if ((districtOutput / MAX) * 100 >= 50)
        {
            IsOverHalf = true;
        } else
        {
            IsOverHalf = false;
        }
        return districtOutput;
    }

}
